// var queryStr = location.search.replace("?","");

// var queryArray = queryStr.split("&");//['name=Sara', 'age=26']

// var assArray = [];

// for(var i=0; i<queryArray.length; i++){
//     var key = queryArray[i].split("=")[0];
//     var val = queryArray[i].split("=")[1];
//     assArray[key] = val;
// }

// document.write("<h1>Welcome ya "+assArray['name']+" &hearts;</h1>")